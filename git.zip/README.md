# wab48Tadiparthi
Express Assignment
Hosted at[https://wab48tadiparthi.herokuapp.com/](https://wab48tadiparthi.herokuapp.com/)<br>
Class name: Soda<br>
Attributes:<br>
company (String)<br>
flavour (String)<br>
price (number)
